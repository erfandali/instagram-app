import 'package:alak/screens/activitiy.dart';
import 'package:alak/screens/home_screen.dart';
import 'package:alak/screens/post.dart';
import 'package:alak/screens/searchpage.dart';
import 'package:alak/screens/user_profile.dart';
import 'package:flutter/material.dart';


class mainacreen extends StatefulWidget {
  const mainacreen({Key? key}) : super(key: key);

  @override
  State<mainacreen> createState() => _mainacreenState();
}

class _mainacreenState extends State<mainacreen> {
  int _settabbbar = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      extendBody: true,
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(15),
          )
        ),
        child: ClipRRect(
           borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            topRight: Radius.circular(15),
          ),
          child: BottomNavigationBar(
            currentIndex: _settabbbar,
            onTap: (int index){
              setState(() {
                _settabbbar = index;
              });
              
            },
            selectedIconTheme: IconThemeData(
              color: Colors.black,
              
            ),
            showUnselectedLabels: false,
            showSelectedLabels: false,
            type: BottomNavigationBarType.fixed,
            backgroundColor: Color(0xff1C1F2E),
            items: [
              BottomNavigationBarItem(icon: Image.asset('images/icon_home (2).png'),label: 'item1'
              ,activeIcon: Image.asset('images/icon_active_home.png'),
              ),
        
              BottomNavigationBarItem(icon: Image.asset('images/icon_search.png')
              ,label: 'item1',
              activeIcon: Image.asset('images/icon_search_navigation_active.png')
              ),
        
              BottomNavigationBarItem(icon: Image.asset('images/icon_add_navigation (1).png')
             , activeIcon: Image.asset('images/icon_add_navigation_active (1).png')
              ,label: 'item1'
              ),
        
              BottomNavigationBarItem(icon: Image.asset('images/icon_activity_navigation (1).png'),
              label: 'item3',
              activeIcon: Image.asset('images/icon_activity_navigation_active (1).png')
              ),
              
               BottomNavigationBarItem(icon: Container(
           
                decoration: BoxDecoration(
                  border:     Border.all(   color: Color.fromARGB(255, 188, 187, 187),width: 2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(2),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: Image.asset('images/photo_2022-07-26_00-35-02.jpg'),
                  ),
                  ),
                ),
                width: 30,
                height: 30,
              ),
              label: 'item3',
              
             activeIcon: Container(
           
                decoration: BoxDecoration(
                  border:     Border.all(   color: Color(0xffF35383),width: 2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(2),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(19),
                  child: FittedBox(
                    fit: BoxFit.cover,
                    child: Image.asset('images/photo_2022-07-26_00-35-02.jpg'),
                  ),
                  ),
                ),
                width: 30,
                height: 30,
              ),
              ),
            
            ],),
        ),
      ),
      body: IndexedStack(
        index: _settabbbar,
        children: getlayots(),
      ),
    );
  }
  List<Widget> getlayots(){
    return <Widget> [
       Homescreens(),
       searchpage(),
       postpage(),
       activitypage(),
       userprofile()
  
    ];
  }
}


