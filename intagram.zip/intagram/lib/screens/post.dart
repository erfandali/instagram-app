import 'package:flutter/material.dart';


class postpage extends StatelessWidget {
  const postpage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
   backgroundColor: Color(0xff1C1F2E),
   body: SafeArea(
     child: Stack(
      alignment: AlignmentDirectional.bottomCenter,
      children: [
       _getcustonscroll(),
          Container(
            height: 78,
            width: double.infinity,
            decoration: BoxDecoration(
              color: Color(0xff272B40),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15),
                topRight: Radius.circular(15),
              ),
            ),
            child: Padding(
               padding: EdgeInsets.only(top: 10, right: 18, left: 18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Draft',style: TextStyle(
                    color: Color(0xffF35383),
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),),
                   Text(
                    'Gallery',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Take',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                  )),
                
                ],
              ),
            ),
     )],
     ),
     
   ),
    );
  }


Widget _getcustonscroll(){
  return CustomScrollView(
      slivers: [
          SliverToBoxAdapter(
          child:_getHeader(),
        ),
        SliverToBoxAdapter(
          child: _getcontaineraddpost(),
        ),
        
         SliverPadding(padding: EdgeInsets.symmetric(horizontal: 18,),
         sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 2.0,
            ),
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child:Image.asset('images/item$index.png'),
                    ),
                  ),
                );
              },
              childCount: 10,
            ),
          ), 
         ),SliverPadding(padding: EdgeInsets.only(bottom: 86))
      ],
     ) ;
}

Widget _getcontaineraddpost(){
  return Container(
      padding: EdgeInsets.symmetric(vertical: 5,horizontal: 18),
      height: 394,
      width: double.infinity,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: Image.asset('images/Rectangle 53.png'),
                    ),
                  ),
                );
}
  Widget _getHeader(){
    return  Padding(
          padding:  EdgeInsets.symmetric(vertical: 27,horizontal: 18),
          child: Row(
            children: [
              Text('post',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 25,
                color: Colors.white
              ),
              ),
              SizedBox(width: 10,),
              Image.asset('images/Vector.png'),
              Spacer(),
              Text('Next',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 21,
                color: Colors.white
              ),
              ),
              SizedBox(width: 10,),
              Image.asset('images/icon_arrow_right_box.png'),
            ],
          ),
        );
  }
}