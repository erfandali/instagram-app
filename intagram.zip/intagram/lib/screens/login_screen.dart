import 'package:alak/screens/mainscreen.dart';
import 'package:alak/screens/switch_accont.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';


class loginscreen extends StatefulWidget {
  const loginscreen({Key? key}) : super(key: key);

  @override
  State<loginscreen> createState() => _loginscreenState();
}

class _loginscreenState extends State<loginscreen> {
  FocusNode negahban = FocusNode();
  FocusNode negahban1 = FocusNode();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    negahban.addListener(() {
      setState(() {});
    });
    negahban1.addListener(() {
      setState(() {});
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
           end: Alignment.bottomCenter,
           colors: [Color.fromARGB(223, 20, 36, 128), Color.fromARGB(255, 255, 0, 230)]
        )
      ),
child: Scaffold(
        backgroundColor: Colors.transparent,
        body: Stack(
          alignment: AlignmentDirectional.bottomCenter,
          children: [_getImageContainer(), _getContainerBox()],
        ),
      ),
    );
  }

Widget _getContainerBox() {
    return Column(
      children: [
        Expanded(child: Container()),
        Expanded(
            child: Container(
          decoration: BoxDecoration(
            color: Color(0xff1C1F2E),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15),
              topRight: Radius.circular(15),
            ),
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(width: double.infinity,),
                
                SingleChildScrollView(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                     Text(
                          'Sign in to ',
                          style: TextStyle(color: Colors.white, fontSize: 23,fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 90,),
                        Image(image: AssetImage('images/Group 141.png'),width: 159,)
                      
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 44),
                  child: TextField(
                     focusNode: negahban1,
                   decoration: InputDecoration(
                    contentPadding:
                            EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                      labelText: 'Email',
                      labelStyle: TextStyle(
                        color: negahban.hasFocus ? Color(0xffF35383) : Colors.white,fontSize: 23,fontWeight: FontWeight.bold
                      ),
                     enabledBorder: OutlineInputBorder(
                      
                       borderRadius: BorderRadius.all(Radius.circular(16),
                       ),
                      borderSide: BorderSide(
                             width: 3,
                             color: Color(0xffC5C5C5),
                     ),
                     
                   ),
                   focusedBorder: OutlineInputBorder(
                           borderRadius: BorderRadius.all(Radius.circular(15)),
                           borderSide: BorderSide(
                             width: 3,
                             color: negahban1.hasFocus? Color(0xffF35383) : Colors.white,
                             
                           ),
                           
               )
            ) ),
                ),
                SizedBox(height: 34,),
                    Padding(
                  padding: EdgeInsets.symmetric(horizontal: 44),
                  child: TextField(
                     focusNode: negahban,
                   decoration: InputDecoration(
                    contentPadding:
                            EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                      labelText: 'password',
                      labelStyle: TextStyle(
                        color:  negahban1.hasFocus
                              ? Color(0xffF35383)
                              : Colors.white,fontSize: 23,fontWeight: FontWeight.bold
                      ),
                     enabledBorder: OutlineInputBorder(
                      
                       borderRadius: BorderRadius.all(Radius.circular(16),
                       ),
                      borderSide: BorderSide(
                             width: 3,
                             color: Color(0xffC5C5C5),
                     ),
                     
                   ),
                   focusedBorder: OutlineInputBorder(
                           borderRadius: BorderRadius.all(Radius.circular(15)),
                           borderSide: BorderSide(
                             width: 3,
                             color: Color(0xffF35383),
                             
                           ),
                           
                           
               ),
               
            ),
            
             ),
             
                ),
                SizedBox(
                  height: 5,
                  width: 5,
                ),
                  SingleChildScrollView
          (
                  child: Container(
                    child: SingleChildScrollView(
                      child: ElevatedButton(
                                        style: Theme.of(context)
                                            .elevatedButtonTheme
                                            .style,
                                                                   onPressed: () {
                                                                      Navigator.push(
                                                                context,
                                                              MaterialPageRoute(builder: (context) => const switchAccont()),
                                                                  ); },
                                        child: Text('Confirm'),
                                      ),
                    ),
                  ),
                )
                ],
             
                   ),
          ),
         
       ),
       
       ),
       
     ],
   );
   
 }

 Widget _getImageContainer() {
   return Positioned(
     left: 0,
     right: 0,
     bottom: 0,
     top: 80,
     child: Column(
       children: [
         Expanded(
           child: Image(
             image: AssetImage('images/rocket.png'),
           ),
         ),
         Expanded(child: Container())
       ],
     ),
    );
  }
  
  @override
  void dispose() {
    negahban.dispose();
    negahban1.dispose();
    // TODO: implement dispose
    super.dispose();
  }

}