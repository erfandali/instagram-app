import 'package:flutter/material.dart';

import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
class searchpage extends StatelessWidget {
const searchpage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Color(0xff1C1F2E),
      body: SafeArea(
        
        child:  CustomScrollView(
          
          slivers: [
            SliverToBoxAdapter(child: _getsearchput()),
            SliverPadding(padding: EdgeInsets.symmetric(horizontal: 16,),
            sliver: SliverGrid(delegate: SliverChildBuilderDelegate(((context, index) {
                return Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(10),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: Image.asset('images/photo_2022-08-11_13-35-56.jpg'),
                    ),
                  ),
                );
              }), childCount: 10),
               gridDelegate:  SliverQuiltedGridDelegate(crossAxisCount: 3,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          repeatPattern: QuiltedGridRepeatPattern.inverted,
          pattern: [
           QuiltedGridTile(2, 1),
            QuiltedGridTile(2, 2),
             QuiltedGridTile(1, 1),
              QuiltedGridTile(1, 1),
               QuiltedGridTile(1, 1),            

          ]       
          ),
          ),
          ),
              
          ],
        )
      ),
    );

    
  }


//            childrenDelegate: SliverChildBuilderDelegate((context, index) {
//              return Container(
//             decoration: BoxDecoration(
              
//               borderRadius: BorderRadius.all(Radius.circular(16),
//               ),
              
//             ),child: ClipRRect(
//               borderRadius: BorderRadius.all(Radius.circular(10),
              
//               ),
//               child: FittedBox(
//                 fit: BoxFit.cover,
//                 child: Image.asset('images/photo_2022-08-11_13-35-56.jpg'),
//               ),
//             ),
//              );
             
//            },
//            childCount: 40),
//            ),

Widget _getsearchput(){
  return Column(children: [
          Container(
            margin: EdgeInsets.only(top: 8,left: 18,right: 18,),
              height: 45,
              width: 375,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(15)),
                color: Color(0xff272B40),
              ),
              child: Padding(
                padding:  EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  children: [
                    Image.asset('images/icon_search.png'),
                    SizedBox(width: 8,),
                    Expanded(child: TextField(
                      
                      decoration: InputDecoration(
                        hintText: 'Search User ',hintStyle: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(228, 253, 254, 255)
                        ),
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none
                      ),
                    ),
                    ),
                    SizedBox( width: 9,),
                    Image.asset('images/Group 55.png')
                  ],
                ),
              ),
            ),  
            _getstory()
        ]);
}

  Widget _getstory() {
  return 
  Container(height: 23 ,
   margin: EdgeInsets.only(top: 21,bottom: 20),
  child: ListView.builder(
             scrollDirection: Axis.horizontal,
             itemCount: 20
             
           ,itemBuilder: ( (context, index) {
            return Container(
              width: 90, 
              height: 25,
              margin: EdgeInsets.only(left: 17,right: 16),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4,horizontal: 18),
                        child: Center(
                          child:   Text('erfdali',style: TextStyle(
                            fontWeight: FontWeight.bold,color: Colors.white,
                            fontSize: 17
                          ),),
                        ),
                      ),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Color(0xff272B40)
                    ),
            );
          
             
           } 
           ),
           ),
  );
}
}