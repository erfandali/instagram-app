import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

class userprofile extends StatelessWidget {
  const userprofile({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      backgroundColor: Color(0xff1C1F2E),
      body: Center(
        child:  DefaultTabController(
          length: 2,
          child: NestedScrollView(
            
            headerSliverBuilder: ((context, innerBoxIsScrolled) {
              return [
                SliverAppBar(
                //  pinned: true,
                toolbarHeight: 80,
                  actions: [
                  Padding(
                    padding:  EdgeInsets.only(top: 18,right: 18),
                    child: Icon(Icons.menu),
                  )
                  ],
                  bottom: PreferredSize(child: Container(
                    height: 14,
                    
                    decoration: BoxDecoration(
                      color: Color(0xff1C1F2E),
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(15),topRight: Radius.circular(15),)
                    ),
                  ),  
                   preferredSize: Size.fromHeight(10)),
                  backgroundColor: Color.fromARGB(255, 28, 31, 46),
                  expandedHeight: 170,
                flexibleSpace: FlexibleSpaceBar(
                  background: Image.asset('images/Rectangle 46.png',fit: BoxFit.cover,),
                ),
                ),
                SliverToBoxAdapter(
        
                  child: _getprofheader(),
                ),
                SliverPersistentHeader(delegate: TabBarViews(
                  
                  TabBar(
                     indicatorWeight: 4.5,
          indicatorPadding: EdgeInsets.symmetric(horizontal: 20),
          indicatorColor: Color(0xffF35383),
                    tabs: [
                   Tab(
                   icon: Image.asset('images/icon_tab_posts.png'),
                  
                   ),
                   Tab(
                    icon: Image.asset('images/icon_tab_bookmark.png'),
                   )
                  ],
                  ),
                ),
                ),
              ];
            }
            
            
            ),
            body: TabBarView(children: [
            CustomScrollView(
              slivers: [
                SliverPadding(
                  padding: EdgeInsets.only(top: 20, left: 18, right: 18),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(((context, index) {
                      return Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(
                            Radius.circular(10),
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: Image.asset('images/item$index.png'),
                          ),
                        ),
                      );
                    }), childCount: 10),
                    gridDelegate: SliverQuiltedGridDelegate(
                        crossAxisCount: 3,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        repeatPattern: QuiltedGridRepeatPattern.inverted,
                        pattern: [
                          QuiltedGridTile(1, 1),
                          QuiltedGridTile(2, 2),
                          QuiltedGridTile(1, 1),
                          QuiltedGridTile(1, 1),
                          QuiltedGridTile(1, 1),
                        ]),
                  ),
                )
              ],
            ),
            CustomScrollView(
              slivers: [
                SliverPadding(
                  padding: EdgeInsets.only(top: 20, left: 18, right: 18),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(((context, index) {
                      return Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(
                            Radius.circular(10),
                          ),
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          child: FittedBox(
                            fit: BoxFit.cover,
                            child: Image.asset('images/item$index.png'),
                          ),
                        ),
                      );
                    }), childCount: 10),
                    gridDelegate: SliverQuiltedGridDelegate(
                        crossAxisCount: 3,
                        mainAxisSpacing: 10,
                        crossAxisSpacing: 10,
                        repeatPattern: QuiltedGridRepeatPattern.inverted,
                        pattern: [
                          QuiltedGridTile(1, 1),
                          QuiltedGridTile(2, 2),
                          QuiltedGridTile(1, 1),
                          QuiltedGridTile(1, 1),
                          QuiltedGridTile(1, 1),
                        ]),
                  ),
                )
              ],
            ),
          ]),
        ),
      ),
    ));
  }


  Widget _getprofheader(){
    return  Padding(
          padding:  EdgeInsets.symmetric(horizontal: 18),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
       
            decoration: BoxDecoration(
              border:     Border.all(   color: Color(0xffF35383),width: 2),
              borderRadius: BorderRadius.circular(17),
            ),
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(19),
              child: FittedBox(
                fit: BoxFit.cover,
                child: Image.asset('images/photo_2022-07-26_00-35-02.jpg'),
              ),
              ),
            ),
            width: 70,
            height: 70,
          ),
          SizedBox(
          width: 13,
          ),
          Container(
             width:241,
            height: 230,
            child: Center(
              child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: 
            CrossAxisAlignment.start,
            children: [
                  Text(' erfdali',style: TextStyle(
                    color: Colors.white,fontWeight: FontWeight.bold,
                    fontFamily: 'SM',fontSize: 18
                  ),
                  ),
                     SizedBox(
          height: 1,
          ),
          Text('erfdali |عرفان دعلی ',style: TextStyle(fontSize: 17,color: Color.fromARGB(255, 219, 216, 216),fontFamily: 'GB',fontWeight: FontWeight.bold),),
            SizedBox(
          height: 2,
          ),        Text('🔰𝗜 𝗽𝗿𝗼𝗺𝗶𝘀𝗲𝗱 𝘁𝗼 𝗮𝗰𝗵𝗶𝗲𝘃𝗲 𝗺𝘆 𝗱𝗿𝗲𝗮𝗺𝘀',style: TextStyle(fontSize: 15,color: Colors.grey,fontFamily: 'GB',fontWeight: FontWeight.bold),),
                    Text('🧊𝕡𝕣𝕠𝕘𝕣𝕒𝕞𝕖𝕣👨‍💻',style: TextStyle(fontSize: 15,color: Colors.grey,fontFamily: 'GB',fontWeight: FontWeight.bold),),
                         Text('⚡️𝙈𝙤𝙗𝙞𝙡𝙚 𝙥𝙧𝙤𝙜𝙧𝙖𝙢𝙢𝙚𝙧 | 𝙁𝙡𝙪𝙩𝙩𝙚𝙧',style: TextStyle(fontSize: 15,color: Colors.grey,fontFamily: 'GB',fontWeight: FontWeight.bold),),
                          
                          Text('🎓𝗣𝗿𝗼𝗴𝗿𝗮𝗺𝗺𝗶𝗻𝗴(𝙁𝙡𝙪𝙩𝙩𝙚𝙧 DEV,....),𝘄𝗲𝗯 𝗽𝗿𝗼𝗴𝗿𝗮𝗺𝗶𝗻𝗴',style: TextStyle(fontSize: 15,color: Colors.grey,fontFamily: 'GB',fontWeight: FontWeight.bold),),
                         Text('📍ɪʀᴀɴ🇮🇷',style: TextStyle(fontSize: 15,color: Colors.grey,fontFamily: 'GB',fontWeight: FontWeight.bold),),

            ],
          ),
            ),
          ),
          Spacer(),
           Image.asset('images/icon_profile_edit.png')
            ],
          ),
        );
  }
}


class TabBarViews extends SliverPersistentHeaderDelegate{
 TabBarViews(this._tabBar);
  final  TabBar _tabBar;


  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    // TODO: implement build
    return Container(
     child: _tabBar
    );
  }

  @override
  // TODO: implement maxExtent
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  // TODO: implement minExtent
  double get minExtent => _tabBar.preferredSize.height;

  @override
  bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) {
    // TODO: implement shouldRebuild
    return false;
  }
   
}