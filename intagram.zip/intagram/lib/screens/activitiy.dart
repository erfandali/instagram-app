import 'package:alak/model/enums/activity_type.dart';
import 'package:flutter/material.dart';

class activitypage extends StatefulWidget {
  const activitypage({Key? key}) : super(key: key);

  @override
  State<activitypage> createState() => _activitypageState() ;
}

class _activitypageState extends State<activitypage> with SingleTickerProviderStateMixin {
  
   TabController? _tabController;
   @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff1C1F2E),
      body: SafeArea(child: 
      Column(
        children: [
          Container(
        color: Color(0xff1C1F2E),
        height: 55,
        child: TabBar(
          controller: _tabController,
          labelStyle: TextStyle(fontWeight: FontWeight.bold,fontSize: 17.2),
          indicatorWeight: 4.5,
          indicatorPadding: EdgeInsets.symmetric(horizontal: 20),
          indicatorColor: Color(0xffF35383),
           tabs: [
                  Tab(
                    text: 'Following',
                  ),
                  Tab(
                    text: 'You',
                  ),
                ],
              ),
      
        ),
        Expanded(child: TabBarView(controller: _tabController,
          children: [
          CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(left: 30,top: 20),
              child: Text('New',   style: TextStyle(
                    fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white),),
            ),
          ),
          SliverList(delegate: SliverChildBuilderDelegate((context, index) {
            
            return _gettextsliver(activitypageState.likes);
            
          },childCount: 3,),
          ),
           SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.only(left: 30, top: 20),
            child: Text(
              'Today',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
          SliverList(delegate: SliverChildBuilderDelegate((context, index) {
            
            return _gettextsliver(activitypageState.followback);
            
          },childCount: 3,),
          ),
          SliverToBoxAdapter(
          child: Padding(
            padding: EdgeInsets.only(left: 30, top: 20),
            child: Text(
              'This Week',
              style: TextStyle(
                  fontSize: 16,fontWeight: FontWeight.bold, color: Colors.white),
            ),
          ),
        ),
          SliverList(delegate: SliverChildBuilderDelegate((context, index) {
            
            return _gettextsliver(activitypageState.following);
            
          },childCount: 2,),
          ),
        ],
          ),
          
          
            CustomScrollView(
        slivers: [
          
          SliverList(delegate: SliverChildBuilderDelegate((context, index) {
            
            return Text('erf');
            
          },childCount: 2,))
        ],
          ),
           
        ],))
        ],
      )
      ),
    );
    
  }
  Widget _gettextsliver(activitypageState state){
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20 ,horizontal: 18),
      child: Row(
        children: [
          Container(
            height: 6,
            width: 6,
            
            decoration: BoxDecoration(
              color: Color(0xffF35383),
            shape: BoxShape.circle,
            ),
          ),
          SizedBox(width: 7.3,),
          SizedBox(
            height: 40,
            width: 40,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: FittedBox(
                fit: BoxFit.cover ,
                child: Image.asset('images/photo_2022-07-26_00-35-02.jpg'),
              ),
            ),
          ),
          SizedBox(width: 10,),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('erfdali',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 16),),
              ),
              Text('Started following',style: TextStyle(color: Color(0xffC5C5C5),fontSize: 15),),
              
                ],
              ),
               Row(
                children: [
                  Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text('you',style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,fontSize: 16),),
              ),
              Text('3min',style: TextStyle(color: Color(0xffC5C5C5),fontSize: 15),),
              
                ],
              )
            ],
          ),
          Spacer(),
          _getactivitystate(state)
       
         
        ],
      ),
    );
  }
  Widget _getactivitystate (activitypageState state){
    switch (state){
      case activitypageState.followback:
      return  ElevatedButton(
                                  style:  ElevatedButton.styleFrom(
      primary: Color(0xffF35383),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(8)
    ),
    textStyle: TextStyle(
      fontFamily: 'GB',fontWeight: FontWeight.w700,fontSize: 16
    )
   ),
                   onPressed: () {
                       },
                child: Text('follow'),
              );
            case activitypageState.likes:
         return     SizedBox(
            height: 40,
            width: 40,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: FittedBox(
                fit: BoxFit.cover ,
                child: Image.asset('images/photo_2022-07-26_00-35-02.jpg'),
              ),
            ),
          );
          case activitypageState.following:
          return     OutlinedButton(onPressed: (){}, child: Text('Massage',style: TextStyle(fontSize: 14,
           color: Color(0xffC5C5C5),
           ),
           ),
           style: OutlinedButton.styleFrom(side: BorderSide(color: Color(0xffC5C5C5))),
           );
           default :
           return     OutlinedButton(onPressed: (){}, child: Text('Massage',style: TextStyle(fontSize: 14,
           color: Color(0xffC5C5C5),
           ),
           ),
           style: OutlinedButton.styleFrom(side: BorderSide(color: Color(0xffC5C5C5))),
           );
    }
  }
}