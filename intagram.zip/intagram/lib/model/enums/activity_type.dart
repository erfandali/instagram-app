enum activitypageState{
  following,
  likes,
  followback,
}